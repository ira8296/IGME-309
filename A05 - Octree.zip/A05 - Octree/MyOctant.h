/*----------------------------------------------
Programmer: Ikenna Ajah (ira8296@rit.edu)
Date: 2017/06
----------------------------------------------*/
#ifndef __MYOCTANTCLASS_H_
#define __MYOCTANTCLASS_H_

#include "MyEntityManager.h"

namespace Simplex
{

//System Class
class MyOctant
{
	static uint m_uOctantCount; //Will store the number of octants instantiated
	static uint m_uMaxLevel; //Will store the maximum level an octant can go to
	static uint m_uIdealEntityCount; //Will tell how many ideal entities this object will contain

	uint m_uID = 0; //Current ID for this octant
	uint m_uLevel = 0; //Current level of the octant
	uint m_uChildren = 0; //Number of children on the octant (either 0 or 8)

	float m_fSize = 0.0f; //Size of the octant

	MeshManager* m_pMeshMngr = nullptr; //Mesh Manager singleton
	MyEntityManager* m_pEntityMngr = nullptr; //Enitity Manager singleton

	vector3 m_v3Center = vector3(0.0f); //Center point of the octant
	vector3 m_v3Min = vector3(0.0f); //Minimum vector of the octant
	vector3 m_v3Max = vector3(0.0f); //Maximum vector of the octant

	MyOctant* m_pParent = nullptr; //Parent of current octant
	MyOctant* m_pChild[8]; //Children of the current octant

	std::vector<uint> m_EntityList; //List of entities under this current octant (Index in Entity Manager)

	MyOctant* m_pRoot = nullptr; //Root octant
	std::vector<MyOctant*> m_lChild; //List of nodes that contain objects (this will be applied to root only)

public:
	//Constructor - will create an octant containing all MagnaEntities Instances in the Mesh
	MyOctant(uint a_nMaxLevel = 2, uint a_nIdealEntityCount = 5);

	//2nd Constructor
	MyOctant(vector3 a_v3Center, float a_fSize);

	//Copy Constructor
	MyOctant(MyOctant const& other);

	//Copy assignment operator
	MyOctant& operator=(MyOctant const& other);

	//Destructor
	~MyOctant(void);

	//Changes object contents for other object's
	void Swap(MyOctant& other);

	//Gets this octant's size
	float GetSize(void);

	//Gets the center of the octant in global space
	vector3 GetCenterGlobal(void);

	//Gets the min corner of the octant in global space
	vector3 GetMinGlobal(void);

	//Gets the max corner of the octant in global space
	vector3 GetMaxGlobal(void);

	//Asks if there is a collision with the Entity specified by index from the Bounding Object Manager
	bool IsColliding(uint a_uRBIndex);

	//Displays the MyOctant volume specified by index including the objects underneath
	void Display(uint a_nIndex, vector3 a_v3Color = C_YELLOW);

	//Displays the MyOctant volume in the color specified
	void Display(vector3 a_v3Color = C_YELLOW);

	//Displays the non-empty leafs in the octree
	void DisplayLeafs(vector3 a_v3Color = C_YELLOW);

	//Clears the entity list for each node
	void ClearEntityList(void);

	//Allocates 8 smaller octants in the child pointers
	void Subdivide(void);

	//Returns the child specified in the index
	MyOctant* GetChild(uint a_nChild);

	//Returns the parent of the octant
	MyOctant* GetParent(void);

	//Asks the MyOctant if it does not contain any children
	bool IsLeaf(void);

	//Asks the MyOctant if it contains more than this many Bounding Objects
	bool ContainsMoreThan(uint a_nEntities);

	//Deletes all children and the children of their children
	void KillBranches(void);

	//Creates a tree using subdivisions, the max number of objects and levels
	void ConstructTree(uint a_nMaxLevel = 3);

	//Traverse the tree up to the leafs and sets the objects in them to the index
	void AssignIDToEntity(void);

	//Gets the total number of octants in the world
	uint GetOctantCount(void);

private:
	//Deallocates member fields
	void Release(void);

	//Allocates member fields
	void Init(void);

	//Creates the list of all leafs that contains objects
	void ConstructList(void);
};//class

} //namespace Simplex

#endif //__OCTANTCLASS_H_



